# Counter

## State Variables
### number

```solidity
uint256 public number;
```


## Functions
### setNumber


```solidity
function setNumber(uint256 newNumber) public;
```

### increment


```solidity
function increment() public;
```

